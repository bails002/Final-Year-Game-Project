keybinds for game:
- the arrow keys are used for movement
- 'f' to use sword
- 'esc' to pause
- 'tab' to access your inventory
- 'p' enter debug mode
- 'n' save game (unfinished)

keybinds for debug mode:
- 't' access the shop 
- 'w' increase max player health
- 's' damage player
- 'e' reset enemy
- 'y' close game
- 'p' exit debug mode
- more to come
demo video:
https://youtu.be/STrYQN-3_2E